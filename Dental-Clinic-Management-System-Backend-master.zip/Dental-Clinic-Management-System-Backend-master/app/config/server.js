const server = {
    server: {
     host: process.env.SERVER_HOST,
     port:  process.env.PORT || 8080,
 }
}

module.exports = server
