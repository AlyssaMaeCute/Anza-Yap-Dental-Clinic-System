const controller = {}
const validator = require('../helper/validator')
const Sequelize = require('sequelize')
const Op = Sequelize.Op
const {sequelize,User} = require('../models/index')



controller.index = (req,res,next)=>{

}


module.exports = controller